/*
 * Copyright (c) 2000-2003, 2007 Apple Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */
/*
 * Copyright 1996 1995 by Open Software Foundation, Inc. 1997 1996 1995 1994 1993 1992 1991  
 *              All Rights Reserved 
 *  
 * Permission to use, copy, modify, and distribute this software and 
 * its documentation for any purpose and without fee is hereby granted, 
 * provided that the above copyright notice appears in all copies and 
 * that both the copyright notice and this permission notice appear in 
 * supporting documentation. 
 *  
 * OSF DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE. 
 *  
 * IN NO EVENT SHALL OSF BE LIABLE FOR ANY SPECIAL, INDIRECT, OR 
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM 
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN ACTION OF CONTRACT, 
 * NEGLIGENCE, OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. 
 * 
 */

/*
 * NOTE - Only the pthread-workqueue pieces remain in this file.
 * [mheily]
 */

#ifndef _POSIX_PTHREAD_INTERNALS_H
#define _POSIX_PTHREAD_INTERNALS_H

/*
 * ADded during the port [mheily]
 */
#define pthread_lock_t  pthread_mutex_t


#include <stdint.h>
#include <sys/queue.h>
#include <pthread.h>

/* keep the size to 64bytes  for both 64 and 32 */
#define _PTHREAD_WORKQUEUE_ATTR_T
typedef struct {
	uint32_t sig;
	int queueprio;
	int overcommit;
	unsigned int resv2[13];
} pthread_workqueue_attr_t;

#define _PTHREAD_WORKITEM_T
typedef struct _pthread_workitem {
	TAILQ_ENTRY(_pthread_workitem) item_entry;	/* pthread_workitem list in prio */
	void	(*func)(void *);
	void	* func_arg;
	struct _pthread_workqueue *  workq;	
	unsigned int	flags;
	unsigned int	gencount;
}  * pthread_workitem_t;

#define PTH_WQITEM_INKERNEL_QUEUE 	1
#define PTH_WQITEM_RUNNING		2
#define PTH_WQITEM_COMPLETED 		4
#define PTH_WQITEM_REMOVED 		8
#define PTH_WQITEM_BARRIER 		0x10
#define PTH_WQITEM_DESTROY 		0x20
#define PTH_WQITEM_NOTINLIST 		0x40
#define PTH_WQITEM_APPLIED 		0x80
#define PTH_WQITEM_KERN_COUNT 		0x100

#define WORKITEM_POOL_SIZE 1000
TAILQ_HEAD(__pthread_workitem_pool, _pthread_workitem);
extern struct __pthread_workitem_pool __pthread_workitem_pool_head;        /* head list of workitem pool  */

#define WQ_NUM_PRIO_QS	3	/* WORKQ_HIGH/DEFAULT/LOW_PRIOQUEUE */

#define _PTHREAD_WORKQUEUE_HEAD_T
typedef struct  _pthread_workqueue_head {
	TAILQ_HEAD(, _pthread_workqueue) wqhead;
	struct _pthread_workqueue * next_workq;	
} * pthread_workqueue_head_t;


#define _PTHREAD_WORKQUEUE_T
typedef struct  _pthread_workqueue {
	unsigned int       sig;	      /* Unique signature for this structure */
	pthread_lock_t lock;	      /* Used for internal mutex on structure */
	TAILQ_ENTRY(_pthread_workqueue) wq_list;	/* workqueue list in prio */
	TAILQ_HEAD(, _pthread_workitem) item_listhead;	/* pthread_workitem list in prio */
	TAILQ_HEAD(, _pthread_workitem) item_kernhead;	/* pthread_workitem list in prio */
	unsigned int	flags;
	size_t		stacksize;
	int		istimeshare;
	int 		importance;
	int 		affinity;
	int		queueprio;
	int		barrier_count;
	int		kq_count;
	void		(*term_callback)(struct _pthread_workqueue *,void *);
	void  * term_callarg;
	pthread_workqueue_head_t headp;
	int		overcommit;
#if defined(__ppc64__) || defined(__x86_64__)
	unsigned int	rev2[2];
#else
	unsigned int	rev2[12];
#endif
}  * pthread_workqueue_t;

#define	 PTHREAD_WORKQ_IN_CREATION	1
#define	 PTHREAD_WORKQ_IN_TERMINATE	2
#define	 PTHREAD_WORKQ_BARRIER_ON	4
#define	 PTHREAD_WORKQ_TERM_ON		8
#define	 PTHREAD_WORKQ_DESTROYED	0x10
#define	 PTHREAD_WORKQ_REQUEUED		0x20
#define	 PTHREAD_WORKQ_SUSPEND		0x40

#define WORKQUEUE_POOL_SIZE 100
TAILQ_HEAD(__pthread_workqueue_pool, _pthread_workqueue);
extern struct __pthread_workqueue_pool __pthread_workqueue_pool_head;        /* head list of workqueue pool  */


#endif /* _POSIX_PTHREAD_INTERNALS_H */
