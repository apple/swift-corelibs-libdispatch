/*
 * Test program by Mark Heily.
 */

#include "pthread_workqueue.h"

int main(int arcg, char **argv[])
{
    pthread_workqueue_init_np();
}
