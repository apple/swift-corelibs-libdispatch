/*
 * Copyright (c) 2000-2008 Apple Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this
 * file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */
/*
 * Copyright 1996 1995 by Open Software Foundation, Inc. 1997 1996 1995 1994 1993 1992 1991  
 *              All Rights Reserved 
 *  
 * Permission to use, copy, modify, and distribute this software and 
 * its documentation for any purpose and without fee is hereby granted, 
 * provided that the above copyright notice appears in all copies and 
 * that both the copyright notice and this permission notice appear in 
 * supporting documentation. 
 *  
 * OSF DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE. 
 *  
 * IN NO EVENT SHALL OSF BE LIABLE FOR ANY SPECIAL, INDIRECT, OR 
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM 
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN ACTION OF CONTRACT, 
 * NEGLIGENCE, OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
 * WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. 
 * 
 */

/*
 * NOTE: Only the pthread_workqueue portions of the original pthread.c remain.
 */

#include <errno.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#include "pthread_internals.h"
#include "pthread_workqueue.h"

static int _pthread_work_internal_init(void);
static void workqueue_list_lock(void);
static void workqueue_list_unlock(void);

/* FIXME: Not sure what __private_extern__ is supposed to do.. */
#define __private_extern__ 
__private_extern__ struct __pthread_workqueue_pool __pthread_workqueue_pool_head = TAILQ_HEAD_INITIALIZER(__pthread_workqueue_pool_head); 
__private_extern__ struct __pthread_workitem_pool __pthread_workitem_pool_head = TAILQ_HEAD_INITIALIZER(__pthread_workitem_pool_head);

static pthread_spinlock_t __workqueue_list_lock;
static int kernel_workq_setup = 0;

struct _pthread_workqueue_head __pthread_workq0_head;
struct _pthread_workqueue_head __pthread_workq1_head;
struct _pthread_workqueue_head __pthread_workq2_head;
pthread_workqueue_head_t __pthread_wq_head_tbl[WQ_NUM_PRIO_QS] = {&__pthread_workq0_head, &__pthread_workq1_head, &__pthread_workq2_head};

static void
workqueue_list_lock()
{
	pthread_spin_lock(&__workqueue_list_lock);
}

static void
workqueue_list_unlock()
{
	pthread_spin_unlock(&__workqueue_list_lock);
}

static int
_pthread_work_internal_init(void)
{
	int i, error;
	pthread_workqueue_head_t headp;
	pthread_workitem_t witemp;
	pthread_workqueue_t wq;

	if (kernel_workq_setup == 0) {
        /* DEADWOOD -- what does this do?
#if defined(__i386__) || defined(__x86_64__)
		__bsdthread_register(thread_start, start_wqthread, round_page(sizeof(struct _pthread)),NULL,NULL, NULL);
#else
		__bsdthread_register(_pthread_start, _pthread_wqthread, round_page(sizeof(struct _pthread)),NULL,NULL, NULL);
#endif

		_pthread_wq_attr_default.queueprio = WORKQ_DEFAULT_PRIOQUEUE;
		_pthread_wq_attr_default.sig = PTHREAD_WORKQUEUE_ATTR_SIG;
        */

		for( i = 0; i< WQ_NUM_PRIO_QS; i++) {
			headp = __pthread_wq_head_tbl[i];
			TAILQ_INIT(&headp->wqhead);
			headp->next_workq = 0;
		}

		/* create work item and workqueue pools */
		witemp = (struct _pthread_workitem *)malloc(sizeof(struct _pthread_workitem) * WORKITEM_POOL_SIZE);
		memset(witemp, 0, (sizeof(struct _pthread_workitem) * WORKITEM_POOL_SIZE));
		for (i = 0; i < WORKITEM_POOL_SIZE; i++) {
			TAILQ_INSERT_TAIL(&__pthread_workitem_pool_head, &witemp[i], item_entry);
		}
		wq = (struct _pthread_workqueue *)malloc(sizeof(struct _pthread_workqueue) * WORKQUEUE_POOL_SIZE);
		bzero(wq, (sizeof(struct _pthread_workqueue) * WORKQUEUE_POOL_SIZE));
		for (i = 0; i < WORKQUEUE_POOL_SIZE; i++) {
			TAILQ_INSERT_TAIL(&__pthread_workqueue_pool_head, &wq[i], wq_list);
		}

#if FIXME
        /* Requires kernel support: see kern/workq_open.c */
		if (error = __workq_open()) {
			TAILQ_INIT(&__pthread_workitem_pool_head);
			TAILQ_INIT(&__pthread_workqueue_pool_head);
			free(witemp);
			free(wq);
			return(ENOMEM);
		}
#else
        error = 1;      /* Suppress warnings */
#endif

		kernel_workq_setup = 1;
	}
	return(0);
}


int
pthread_workqueue_init_np()
{
	int ret;

    pthread_spin_init(&__workqueue_list_lock, PTHREAD_PROCESS_PRIVATE);
	workqueue_list_lock();
	ret =_pthread_work_internal_init();
	workqueue_list_unlock();

	return(ret);
}

