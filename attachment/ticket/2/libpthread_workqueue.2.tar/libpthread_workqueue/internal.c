
/* This routine is called with list lock held */
static pthread_workitem_t
alloc_workitem(void)
{
	pthread_workitem_t witem;

	if (TAILQ_EMPTY(&__pthread_workitem_pool_head)) {
		workqueue_list_unlock();
		witem = malloc(sizeof(struct _pthread_workitem));
		witem->gencount = 0;
		workqueue_list_lock();
	} else {
		witem = TAILQ_FIRST(&__pthread_workitem_pool_head);
		TAILQ_REMOVE(&__pthread_workitem_pool_head, witem, item_entry);
	}
	return(witem);
}

/* This routine is called with list lock held */
static void
free_workitem(pthread_workitem_t witem) 
{
	witem->gencount++;
	TAILQ_INSERT_TAIL(&__pthread_workitem_pool_head, witem, item_entry);
}

/* This routine is called with list lock held */
static pthread_workqueue_t
alloc_workqueue(void)
{
	pthread_workqueue_t wq;

	if (TAILQ_EMPTY(&__pthread_workqueue_pool_head)) {
		workqueue_list_unlock();
		wq = malloc(sizeof(struct _pthread_workqueue));
		workqueue_list_lock();
	} else {
		wq = TAILQ_FIRST(&__pthread_workqueue_pool_head);
		TAILQ_REMOVE(&__pthread_workqueue_pool_head, wq, wq_list);
	}
	user_workq_count++;
	return(wq);
}

/* This routine is called with list lock held */
static void
free_workqueue(pthread_workqueue_t wq) 
{
	user_workq_count--;
	TAILQ_INSERT_TAIL(&__pthread_workqueue_pool_head, wq, wq_list);
}

/* called with list lock */
static void
pick_nextworkqueue_droplock()
{
	int i, curwqprio, val, found;
	pthread_workqueue_head_t headp;
	pthread_workqueue_t workq;
	pthread_workqueue_t nworkq = NULL;

#if WQ_TRACE
	__kdebug_trace(0x9008098, kernel_workq_count, 0, 0,  0, 0);
#endif
loop:
	while (kernel_workq_count < KERNEL_WORKQ_ELEM_MAX) {
		found = 0;
		for (i = 0; i < WQ_NUM_PRIO_QS; i++)  {
			wqreadyprio = i;	/* because there is nothing else higher to run */
			headp = __pthread_wq_head_tbl[i];

			if (TAILQ_EMPTY(&headp->wqhead))
				continue;
			workq = headp->next_workq;
			if (workq == NULL)
				workq = TAILQ_FIRST(&headp->wqhead);
			curwqprio = workq->queueprio;
			nworkq = workq;	/* starting pt */
			while (kernel_workq_count < KERNEL_WORKQ_ELEM_MAX) {
				headp->next_workq = TAILQ_NEXT(workq, wq_list);
				if (headp->next_workq == NULL)
					headp->next_workq = TAILQ_FIRST(&headp->wqhead);
#if WQ_TRACE
	__kdebug_trace(0x9008098, kernel_workq_count, workq, 0,  1, 0);
#endif
				val = post_nextworkitem(workq);

				if (val != 0) {
					/* things could have changed so reasses */
					/* If kernel queue is full , skip */
					if (kernel_workq_count >= KERNEL_WORKQ_ELEM_MAX)
						break;
					/* If anything with higher prio arrived, then reevaluate */
					if (wqreadyprio < curwqprio)
						goto loop;	/* we need re evaluate again */
					/* we can post some more work items */
					found = 1;
				}

				/* cannot use workq here as it could be freed */
				if (TAILQ_EMPTY(&headp->wqhead))
					break;
				/* if we found nothing to run and only one workqueue in the list, skip */
				if ((val == 0) && (workq == headp->next_workq))
					break;
				workq = headp->next_workq;
				if (workq == NULL)
					workq = TAILQ_FIRST(&headp->wqhead);
				if (val != 0)
					nworkq = workq;
				/* if we found nothing to run and back to workq where we started */
				if ((val == 0) && (workq == nworkq))
					break;
			}
			if (kernel_workq_count >= KERNEL_WORKQ_ELEM_MAX)
				break;
		}
		/* nothing found to run?  */
		if (found == 0)
			break;
	}
	workqueue_list_unlock();
}

static int
post_nextworkitem(pthread_workqueue_t workq)
{
	int error, prio;
	pthread_workitem_t witem;
	pthread_workqueue_head_t headp;
	void (*func)(pthread_workqueue_t, void *);

		if ((workq->flags & PTHREAD_WORKQ_SUSPEND) == PTHREAD_WORKQ_SUSPEND) {
			return(0);
		}
#if WQ_TRACE
		__kdebug_trace(0x900809c, workq, workq->item_listhead.tqh_first, 0, 1, 0);
#endif
		if (TAILQ_EMPTY(&workq->item_listhead)) {
			return(0);
		}
		if ((workq->flags & PTHREAD_WORKQ_BARRIER_ON) ==  PTHREAD_WORKQ_BARRIER_ON)
				return(0);

		witem = TAILQ_FIRST(&workq->item_listhead);
		headp = workq->headp;
#if WQ_TRACE
		__kdebug_trace(0x900809c, workq, witem, 0, 0xee, 0);
#endif
		if ((witem->flags & PTH_WQITEM_BARRIER) == PTH_WQITEM_BARRIER) {
#if WQ_TRACE
			__kdebug_trace(0x9000064, workq, 0, 0, 2, 0);
#endif
			
			if ((witem->flags & PTH_WQITEM_APPLIED) != 0) {
				return(0);
			}
			/* Also barrier when nothing is there needs to be handled */
			/* Nothing to wait for */
			if (workq->kq_count != 0) {
				witem->flags |= PTH_WQITEM_APPLIED;
				workq->flags |= PTHREAD_WORKQ_BARRIER_ON;
				workq->barrier_count = workq->kq_count;
#if WQ_TRACE
			__kdebug_trace(0x9000064, 1, workq->barrier_count, 0, 0, 0);
#endif
				return(1);
			} else {
#if WQ_TRACE
			__kdebug_trace(0x9000064, 2, workq->barrier_count, 0, 0, 0);
#endif
				if (witem->func != NULL) {
				/* since we are going to drop list lock */
				witem->flags |= PTH_WQITEM_APPLIED;
				workq->flags |= PTHREAD_WORKQ_BARRIER_ON;
				        workqueue_list_unlock();
					func = (void (*)(pthread_workqueue_t, void *))witem->func;
					(*func)(workq, witem->func_arg);
#if WQ_TRACE
			__kdebug_trace(0x9000064, 3, workq->barrier_count, 0, 0, 0);
#endif
					workqueue_list_lock();
					workq->flags &= ~PTHREAD_WORKQ_BARRIER_ON;
				}
				TAILQ_REMOVE(&workq->item_listhead, witem, item_entry);
#if WQ_LISTTRACE
	__kdebug_trace(0x90080a8, workq, &workq->item_listhead, workq->item_listhead.tqh_first,  workq->item_listhead.tqh_last, 0);
#endif
				witem->flags = 0;
				free_workitem(witem);
#if WQ_TRACE
			__kdebug_trace(0x9000064, 4, workq->barrier_count, 0, 0, 0);
#endif
				return(1);
			}
		} else if ((witem->flags & PTH_WQITEM_DESTROY) == PTH_WQITEM_DESTROY) {
#if WQ_TRACE
			__kdebug_trace(0x9000068, 1, workq->kq_count, 0, 0, 0);
#endif
			if ((witem->flags & PTH_WQITEM_APPLIED) != 0) {
				return(0);
			}
			witem->flags |= PTH_WQITEM_APPLIED;
			workq->flags |= (PTHREAD_WORKQ_BARRIER_ON | PTHREAD_WORKQ_TERM_ON);
			workq->barrier_count = workq->kq_count;
			workq->term_callback = (void (*)(struct _pthread_workqueue *,void *))witem->func;
			workq->term_callarg = witem->func_arg;
			TAILQ_REMOVE(&workq->item_listhead, witem, item_entry);
#if WQ_LISTTRACE
	__kdebug_trace(0x90080a8, workq, &workq->item_listhead, workq->item_listhead.tqh_first,  workq->item_listhead.tqh_last, 0);
#endif
			if ((TAILQ_EMPTY(&workq->item_listhead)) && (workq->kq_count == 0)) {
				if (!(TAILQ_EMPTY(&workq->item_kernhead))) {
#if WQ_TRACE
				__kdebug_trace(0x900006c, workq, workq->kq_count, 0, 0xff, 0);
#endif
				}
				witem->flags = 0;
				free_workitem(witem);
				workq->flags |= PTHREAD_WORKQ_DESTROYED;
#if WQ_TRACE
			__kdebug_trace(0x900006c, workq, workq->kq_count, 0, 1, 0);
#endif
				headp = __pthread_wq_head_tbl[workq->queueprio];
				if (headp->next_workq == workq) {
					headp->next_workq = TAILQ_NEXT(workq, wq_list);
					if (headp->next_workq == NULL) {
						headp->next_workq = TAILQ_FIRST(&headp->wqhead);
						if (headp->next_workq == workq)
							headp->next_workq = NULL;
					}
				}
				workq->sig = 0;
				TAILQ_REMOVE(&headp->wqhead, workq, wq_list);
				if (workq->term_callback != NULL) {
				        workqueue_list_unlock();
					(*workq->term_callback)(workq, workq->term_callarg);
					workqueue_list_lock();
				}
				free_workqueue(workq);
				return(1);
			} else  {
				TAILQ_INSERT_HEAD(&workq->item_listhead, witem, item_entry);
#if WQ_LISTTRACE
	__kdebug_trace(0x90080b0, workq, &workq->item_listhead, workq->item_listhead.tqh_first,  workq->item_listhead.tqh_last, 0);
#endif
			}
#if WQ_TRACE
			__kdebug_trace(0x9000068, 2, workq->barrier_count, 0, 0, 0);
#endif
			return(1);
		}  else {
#if WQ_TRACE
			__kdebug_trace(0x9000060, witem, workq, witem->func_arg, 0xfff, 0);
#endif
			TAILQ_REMOVE(&workq->item_listhead, witem, item_entry);
#if WQ_LISTTRACE
	__kdebug_trace(0x90080a8, workq, &workq->item_listhead, workq->item_listhead.tqh_first,  workq->item_listhead.tqh_last, 0);
#endif
			TAILQ_INSERT_TAIL(&workq->item_kernhead, witem, item_entry);
			if ((witem->flags & PTH_WQITEM_KERN_COUNT) == 0) {
				workq->kq_count++;
				witem->flags |= PTH_WQITEM_KERN_COUNT;
			}
			OSAtomicIncrement32(&kernel_workq_count);
			workqueue_list_unlock();
			
			prio = workq->queueprio;
			if (workq->overcommit != 0) {
				prio |= WORKQUEUE_OVERCOMMIT;
			}

#if FIXME
            /* Requires kernel support */
			if (( error =__workq_kernreturn(WQOPS_QUEUE_ADD, witem, workq->affinity, prio)) == -1) {
#else
                error = 0;
                if (1) {
#endif /* FIXME */
				OSAtomicDecrement32(&kernel_workq_count);
				workqueue_list_lock();
#if WQ_TRACE
			__kdebug_trace(0x900007c, witem, workq, witem->func_arg, workq->kq_count, 0);
#endif
				TAILQ_REMOVE(&workq->item_kernhead, witem, item_entry);
				TAILQ_INSERT_HEAD(&workq->item_listhead, witem, item_entry);
#if WQ_LISTTRACE
	__kdebug_trace(0x90080b0, workq, &workq->item_listhead, workq->item_listhead.tqh_first,  workq->item_listhead.tqh_last, 0);
#endif
				if ((workq->flags & (PTHREAD_WORKQ_BARRIER_ON | PTHREAD_WORKQ_TERM_ON)) != 0)
					workq->flags |= PTHREAD_WORKQ_REQUEUED;
			} else
				workqueue_list_lock();
#if WQ_TRACE
			__kdebug_trace(0x9000060, witem, workq, witem->func_arg, workq->kq_count, 0);
#endif
			return(1);
		}
		/* noone should come here */
#if FIXME
            /* This block was enabled in the original source */
		printf("error in logic for next workitem\n");
		LIBC_ABORT("error in logic for next workitem");
#endif
		return(0);
}

static void
workqueue_exit(pthread_t self, pthread_workqueue_t workq, pthread_workitem_t item)
{
	pthread_workitem_t baritem;
	pthread_workqueue_head_t headp;
	void (*func)(pthread_workqueue_t, void *);
	
	workqueue_list_lock();

	TAILQ_REMOVE(&workq->item_kernhead, item, item_entry);
	workq->kq_count--;
#if WQ_TRACE
	__kdebug_trace(0x9000070, self, 1, item->func_arg, workq->kq_count, 0);
#endif
	item->flags = 0;
	free_workitem(item);

	if ((workq->flags & PTHREAD_WORKQ_BARRIER_ON) == PTHREAD_WORKQ_BARRIER_ON) {
		workq->barrier_count--;
#if WQ_TRACE
		__kdebug_trace(0x9000084, self, workq->barrier_count, workq->kq_count, 1, 0);
#endif
		if (workq->barrier_count <= 0 ) {
			/* Need to remove barrier item from the list */
			baritem = TAILQ_FIRST(&workq->item_listhead);
#if WQ_DEBUG
			if ((baritem->flags & (PTH_WQITEM_BARRIER | PTH_WQITEM_DESTROY| PTH_WQITEM_APPLIED)) == 0)
				printf("Incorect bar item being removed in barrier processing\n");
#endif /* WQ_DEBUG */
			/* if the front item is a barrier and call back is registered, run that */
			 if (((baritem->flags & PTH_WQITEM_BARRIER) == PTH_WQITEM_BARRIER) && (baritem->func != NULL)) {
				workqueue_list_unlock();
				func = (void (*)(pthread_workqueue_t, void *))baritem->func;
				(*func)(workq, baritem->func_arg);
				workqueue_list_lock();
			}
			TAILQ_REMOVE(&workq->item_listhead, baritem, item_entry);
#if WQ_LISTTRACE
	__kdebug_trace(0x90080a8, workq, &workq->item_listhead, workq->item_listhead.tqh_first,  workq->item_listhead.tqh_last, 0);
#endif
			baritem->flags = 0;
			free_workitem(baritem);
			workq->flags &= ~PTHREAD_WORKQ_BARRIER_ON;
#if WQ_TRACE
			__kdebug_trace(0x9000058, self, item, item->func_arg, 0, 0);
#endif
			if ((workq->flags & PTHREAD_WORKQ_TERM_ON) != 0) {
				headp = __pthread_wq_head_tbl[workq->queueprio];
				workq->flags |= PTHREAD_WORKQ_DESTROYED;
#if WQ_TRACE
			__kdebug_trace(0x900006c, workq, workq->kq_count, 0, 2, 0);
#endif
				if (headp->next_workq == workq) {
					headp->next_workq = TAILQ_NEXT(workq, wq_list);
					if (headp->next_workq == NULL) {
						headp->next_workq = TAILQ_FIRST(&headp->wqhead);
						if (headp->next_workq == workq)
							headp->next_workq = NULL;
					}
				}
				TAILQ_REMOVE(&headp->wqhead, workq, wq_list);
				workq->sig = 0;
				if (workq->term_callback != NULL) {
				        workqueue_list_unlock();
					(*workq->term_callback)(workq, workq->term_callarg);
					workqueue_list_lock();
				}
				free_workqueue(workq);
			} else {
			/* if there are higher prio schedulabel item reset to wqreadyprio */
				if ((workq->queueprio < wqreadyprio) && (!(TAILQ_EMPTY(&workq->item_listhead))))
						wqreadyprio = workq->queueprio;
			}
		}
	} 
#if WQ_TRACE
	else {
		__kdebug_trace(0x9000070, self, 2, item->func_arg, workq->barrier_count, 0);
	}
	
	__kdebug_trace(0x900005c, self, item, 0, 0, 0);
#endif
	pick_nextworkqueue_droplock();
	_pthread_workq_return(self);
}

static void 
_pthread_workq_return(pthread_t self)
{
#if FIXME
	__workq_kernreturn(WQOPS_THREAD_RETURN, NULL, 0, 0);
#endif

	/* This is the way to terminate the thread */
	pthread_exit(NULL);
}

void
_pthread_wqthread(pthread_t self, void * stackaddr, pthread_workitem_t item, int reuse)
{
	int ret;
	pthread_attr_t *attrs = &_pthread_attr_default;
	pthread_workqueue_t workq;
#if WQ_DEBUG
	pthread_t pself;
#endif


	workq = item->workq;
	if (reuse == 0) {
		/* reuse is set to 0, when a thread is newly created to run a workitem */
		_pthread_struct_init(self, attrs, stackaddr,  DEFAULT_STACK_SIZE, 1, 1);
		self->wqthread = 1;
		self->wqkillset = 0;
		self->parentcheck = 1;

		/* These are not joinable threads */
		self->detached &= ~PTHREAD_CREATE_JOINABLE;
		self->detached |= PTHREAD_CREATE_DETACHED;
#if defined(__i386__) || defined(__x86_64__)
		_pthread_set_self(self);
#endif
#if WQ_TRACE
		__kdebug_trace(0x9000050, self, item, item->func_arg, 0, 0);
#endif
		self->fun = (void *(*)(void *))item->func;
		self->arg = item->func_arg;
		/* Add to the pthread list */
		LOCK(_pthread_list_lock);
		TAILQ_INSERT_TAIL(&__pthread_head, self, plist);
#if PTH_LISTTRACE
		__kdebug_trace(0x900000c, self, 0, 0, 10, 0);
#endif
		_pthread_count++;
		UNLOCK(_pthread_list_lock);

#if defined(__i386__) || defined(__x86_64__) || defined(__arm__)
		if( (self->thread_id = __thread_selfid()) == (__uint64_t)-1)
			printf("Failed to set thread_id in pthread_wqthread\n");
#endif

	} else  {
		/* reuse is set to 1, when a thread is resued to run another work item */
#if WQ_TRACE
		__kdebug_trace(0x9000054, self, item, item->func_arg, 0, 0);
#endif
		/* reset all tsd from 1 to KEYS_MAX */
		if (self == NULL)
			LIBC_ABORT("_pthread_wqthread: pthread %p setup to be NULL", self);

		self->fun = (void *(*)(void *))item->func;
		self->arg = item->func_arg;
	}

#if WQ_DEBUG
	if (reuse == 0) {
		pself = pthread_self();
		if (self != pself) {
#if WQ_TRACE
		__kdebug_trace(0x9000078, self, pself, item->func_arg, 0, 0);
#endif
			printf("pthread_self not set: pself %p, passed in %p\n", pself, self);
    			_pthread_set_self(self);
			pself = pthread_self();
			if (self != pself)
				printf("(2)pthread_self not set: pself %p, passed in %p\n", pself, self);
			pself = self;
		}
	} else {
		pself = pthread_self();
		if (self != pself) {
			printf("(3)pthread_self not set in reuse: pself %p, passed in %p\n", pself, self);
			LIBC_ABORT("(3)pthread_self not set in reuse: pself %p, passed in %p", pself, self);
		}
	}
#endif /* WQ_DEBUG */

	self->cur_workq = workq;
	self->cur_workitem = item;
	OSAtomicDecrement32(&kernel_workq_count);

	ret = (int)(intptr_t)(*self->fun)(self->arg);

	/* If we reach here without going through the above initialization path then don't go through
	 * with the teardown code path ( e.g. setjmp/longjmp ). Instead just exit this thread.
	 */
	if(self != pthread_self()) {
		pthread_exit(PTHREAD_CANCELED);
	}
	
	workqueue_exit(self, workq, item);

}
